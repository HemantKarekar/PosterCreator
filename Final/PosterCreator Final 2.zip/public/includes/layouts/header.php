<header>
    <nav class="navbar">
        <div class="brand">
            <a href="index.php"><img src="assets/images/logo-wr.png" alt=""></a>
        </div>
    </nav>
</header>
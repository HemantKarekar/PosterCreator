<footer>
    <div class="foo-content">
        <hr>
        <div class="brand-partners">
            <div class="partner">
                <div class="logo">
                    <img src="assets/images/cims_logo.png" alt="">
                </div>
            </div>
        </div>
        <div class="copyright">Copyright ©2020. All rights reserved | CIMS </div>
    </div>
</footer>
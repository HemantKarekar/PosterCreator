<div class="navbar">
    Navbar
</div>